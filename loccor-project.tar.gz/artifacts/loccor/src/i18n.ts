export type Lang = "ar" | "fr" | "en";

export type Translations = {
  nav_home: string;
  nav_fleet: string;
  nav_admin: string;
  nav_about: string;
  nav_contact: string;
  btn_book_now: string;
  hero_badge: string;
  hero_title: string;
  hero_subtitle: string;
  btn_search: string;
  how_it_works: string;
  step1_title: string;
  step1_desc: string;
  step2_title: string;
  step2_desc: string;
  step3_title: string;
  step3_desc: string;
  filters: string;
  cat_title: string;
  trans_title: string;
  cars_found: string;
  sort_price: string;
  sort_rating: string;
  sort_new: string;
  modal_title: string;
  stat1: string;
  stat2: string;
  stat3: string;
  stat4: string;
  popular: string;
  section_how_badge: string;
  section_featured: string;
  section_featured_badge: string;
  see_all: string;
  view_all_cars: string;
  why_badge: string;
  why_title: string;
  testi_badge: string;
  testi_title: string;
  fleet_title: string;
  fleet_sub: string;
  apply_filters: string;
  load_more: string;
  price_range: string;
  about_title: string;
  contact_title: string;
  footer_desc: string;
  partners_label: string;
  step1_modal_title: string;
  confirm_title: string;
  confirm_msg1: string;
  confirm_msg2: string;
  next_step: string;
  back: string;
  close_btn: string;
  trust1: string;
  trust2: string;
  trust3: string;
  trust4: string;
  step_num1: string;
  step_num2: string;
  step_num3: string;
  why1_title: string;
  why1_desc: string;
  why2_title: string;
  why2_desc: string;
  why3_title: string;
  why3_desc: string;
  why4_title: string;
  why4_desc: string;
  city_placeholder: string;
  search_label: string;
  login_title: string;
  login_sub: string;
  login_user: string;
  login_pass: string;
  login_btn: string;
  login_error: string;
  per_day: string;
  reserve_btn: string;
  book_label: string;
  book_name: string;
  book_phone: string;
  book_email: string;
  book_notes: string;
  payment_title: string;
  pay_card: string;
  pay_virement: string;
  pay_cash: string;
  step1_error: string;
  step2_error: string;
  footer_links: string;
  footer_quick: string;
  footer_support: string;
  footer_legal: string;
  footer_contact_title: string;
  footer_rights: string;
  about_sub: string;
  about_mission_title: string;
  about_mission_text: string;
  contact_sub: string;
  contact_email_label: string;
  contact_phone_label: string;
  contact_msg_label: string;
  contact_send: string;
  contact_success: string;
  admin_dash: string;
  admin_fleet: string;
  admin_bookings: string;
  admin_agencies: string;
  admin_stats: string;
  admin_invitations: string;
  inv_title: string;
  inv_sub: string;
  inv_add_btn: string;
  inv_search_ph: string;
  inv_col_agency: string;
  inv_col_city: string;
  inv_col_contact: string;
  inv_col_status: string;
  inv_col_actions: string;
  inv_send: string;
  inv_resend: string;
  inv_status_pending: string;
  inv_status_invited: string;
  inv_status_active: string;
  inv_status_rejected: string;
  inv_modal_title: string;
  inv_name_ph: string;
  inv_city_ph: string;
  inv_email_ph: string;
  inv_phone_ph: string;
  inv_msg_label: string;
  inv_msg_ph: string;
  inv_cancel: string;
  inv_confirm_send: string;
  inv_sent_toast: string;
  inv_stats_total: string;
  inv_stats_invited: string;
  inv_stats_active: string;
  inv_stats_pending: string;
  inv_filter_all: string;
};

const ar: Translations = {
  nav_home: "الرئيسية",
  nav_fleet: "أسطول السيارات",
  nav_admin: "الفضاء المهني",
  nav_about: "من نحن",
  nav_contact: "اتصل بنا",
  btn_book_now: "احجز الآن",
  hero_badge: "🌟 المنصة رقم 1 فالمغرب",
  hero_title: "سافر بحرية،",
  hero_subtitle: "أكثر من 150 وكالة موثوقة · حجز فالبلاصة · إلغاء مجاني",
  btn_search: "بحث",
  how_it_works: "كيفاش كيخدم الموقع؟",
  step1_title: "اختار الطوموبيل",
  step1_desc: "قارن بين مئات السيارات من وكالات مغربية موثوقة ومختارة بعناية.",
  step2_title: "خلص التسبيق",
  step2_desc: "خلص غير 15% باش تأكد الحجز ديالك. الدفع آمن 100%.",
  step3_title: "استلم الساروت",
  step3_desc: "تواصل مباشرة مع الوكالة وخلص الباقي ملي تاخد الطوموبيل.",
  filters: "التصفية",
  cat_title: "النوع",
  trans_title: "علبة السرعة",
  cars_found: "142 سيارة متاحة",
  sort_price: "الأرخص أولاً",
  sort_rating: "الأعلى تقييماً",
  sort_new: "الأحدث",
  modal_title: "تأكيد الحجز",
  stat1: "وكالة شريكة",
  stat2: "حجز ناجح",
  stat3: "معدل التقييم",
  stat4: "مدينة مغطاة",
  popular: "الأكثر بحثاً:",
  section_how_badge: "الطريقة",
  section_featured: "الأكثر حجزاً هذا الأسبوع",
  section_featured_badge: "السيارات المميزة",
  see_all: "شوف الكل ←",
  view_all_cars: "شوف جميع السيارات",
  why_badge: "لماذا لوكور؟",
  why_title: "الضمانات ديالنا",
  testi_badge: "آراء العملاء",
  testi_title: "ماذا قالو عنا",
  fleet_title: "أسطول السيارات",
  fleet_sub: "اختر من بين 142 سيارة متاحة في 17 مدينة مغربية",
  apply_filters: "تطبيق الفلاتر",
  load_more: "تحميل المزيد",
  price_range: "نطاق السعر / يوم",
  about_title: "من نحن",
  contact_title: "اتصل بنا",
  footer_desc: "منصة مغربية 100% لتأجير السيارات.",
  partners_label: "شركاؤنا الموثوقون",
  step1_modal_title: "معلوماتك الشخصية",
  confirm_title: "تم تأكيد حجزك! 🎉",
  confirm_msg1: "سيصلك تأكيد عبر WhatsApp وEmail خلال 5 دقائق.",
  confirm_msg2: "هذا نموذج تجريبي – في الواقع ستُوجَّه لصفحة الدفع.",
  next_step: "التالي →",
  back: "← رجوع",
  close_btn: "إنهاء",
  trust1: "✅ إلغاء مجاني قبل 48 ساعة",
  trust2: "🔒 دفع آمن 100%",
  trust3: "📞 دعم 7/7 من 8h إلى 22h",
  trust4: "🏆 +15,000 حجز ناجح في 2024",
  step_num1: "الخطوة 1",
  step_num2: "الخطوة 2",
  step_num3: "الخطوة 3",
  why1_title: "أسعار شفافة",
  why1_desc: "لا تكاليف خفية. السعر المعروض هو السعر النهائي.",
  why2_title: "وكالات موثوقة",
  why2_desc: "+150 وكالة مختارة ومراقبة من طرف فريقنا.",
  why3_title: "حجز فوري",
  why3_desc: "تأكيد الحجز خلال دقائق. لا انتظار لا تعقيد.",
  why4_title: "دعم على مدار الساعة",
  why4_desc: "فريقنا متوفر 7/7 للإجابة على كل أسئلتك.",
  city_placeholder: "مدينة أو مطار...",
  search_label: "ابحث",
  login_title: "الفضاء المهني",
  login_sub: "أدخل بيانات الدخول للوصول إلى لوحة التحكم",
  login_user: "اسم المستخدم",
  login_pass: "كلمة المرور",
  login_btn: "دخول",
  login_error: "بيانات الدخول غير صحيحة",
  per_day: "/يوم",
  reserve_btn: "حجز الآن",
  book_label: "احجز الآن",
  book_name: "الاسم الكامل",
  book_phone: "رقم الهاتف",
  book_email: "البريد الإلكتروني (اختياري)",
  book_notes: "ملاحظات (اختياري)",
  payment_title: "اختر طريقة الدفع",
  pay_card: "بطاقة بنكية",
  pay_virement: "تحويل بنكي",
  pay_cash: "نقداً عند الاستلام",
  step1_error: "من فضلك أدخل الاسم ورقم الهاتف",
  step2_error: "من فضلك اختر طريقة الدفع",
  footer_links: "روابط سريعة",
  footer_quick: "الصفحات",
  footer_support: "الدعم",
  footer_legal: "قانوني",
  footer_contact_title: "تواصل معنا",
  footer_rights: "جميع الحقوق محفوظة",
  about_sub: "منصة رائدة في تأجير السيارات بالمغرب منذ 2020",
  about_mission_title: "مهمتنا",
  about_mission_text: "نربط المسافرين بأفضل وكالات تأجير السيارات في المغرب بطريقة شفافة وآمنة وموثوقة.",
  contact_sub: "نحن هنا للمساعدة. تواصل معنا في أي وقت.",
  contact_email_label: "البريد الإلكتروني",
  contact_phone_label: "رقم الهاتف",
  contact_msg_label: "رسالتك",
  contact_send: "إرسال",
  contact_success: "تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.",
  admin_dash: "لوحة التحكم",
  admin_fleet: "الأسطول",
  admin_bookings: "الحجوزات",
  admin_agencies: "الوكالات",
  admin_stats: "الإحصائيات",
  admin_invitations: "الدعوات",
  inv_title: "دليل الوكالات والدعوات",
  inv_sub: "أضف وكالات وأرسل لها دعوات للانضمام إلى منصة LOCCOR",
  inv_add_btn: "+ إضافة وكالة",
  inv_search_ph: "ابحث عن وكالة...",
  inv_col_agency: "الوكالة",
  inv_col_city: "المدينة",
  inv_col_contact: "التواصل",
  inv_col_status: "الحالة",
  inv_col_actions: "الإجراءات",
  inv_send: "إرسال دعوة",
  inv_resend: "إعادة إرسال",
  inv_status_pending: "بانتظار",
  inv_status_invited: "تمت الدعوة",
  inv_status_active: "نشط",
  inv_status_rejected: "مرفوض",
  inv_modal_title: "إضافة وكالة وإرسال دعوة",
  inv_name_ph: "اسم الوكالة",
  inv_city_ph: "المدينة",
  inv_email_ph: "البريد الإلكتروني",
  inv_phone_ph: "رقم الهاتف",
  inv_msg_label: "رسالة الدعوة",
  inv_msg_ph: "اكتب رسالة مخصصة...",
  inv_cancel: "إلغاء",
  inv_confirm_send: "إضافة وإرسال الدعوة",
  inv_sent_toast: "✅ تم إرسال الدعوة بنجاح!",
  inv_stats_total: "إجمالي الوكالات",
  inv_stats_invited: "دعوة مرسلة",
  inv_stats_active: "نشط على المنصة",
  inv_stats_pending: "بانتظار الرد",
  inv_filter_all: "الكل",
};

const fr: Translations = {
  nav_home: "Accueil",
  nav_fleet: "Notre Flotte",
  nav_admin: "Espace Pro",
  nav_about: "À propos",
  nav_contact: "Contact",
  btn_book_now: "Réserver",
  hero_badge: "🌟 Plateforme N°1 au Maroc",
  hero_title: "Voyagez libre,",
  hero_subtitle: "Plus de 150 agences vérifiées · Réservation instantanée · Annulation gratuite",
  btn_search: "Rechercher",
  how_it_works: "Comment ça marche ?",
  step1_title: "Choisissez",
  step1_desc: "Comparez des centaines de véhicules d'agences marocaines fiables et sélectionnées avec soin.",
  step2_title: "Acompte",
  step2_desc: "Payez seulement 15% pour bloquer la voiture. Paiement 100% sécurisé.",
  step3_title: "Roulez",
  step3_desc: "Récupérez les clés directement en agence et payez le reste sur place.",
  filters: "Filtres",
  cat_title: "Catégorie",
  trans_title: "Boîte de vitesse",
  cars_found: "142 véhicules disponibles",
  sort_price: "Moins cher",
  sort_rating: "Mieux notés",
  sort_new: "Les plus récents",
  modal_title: "Confirmation de réservation",
  stat1: "agences partenaires",
  stat2: "réservations réussies",
  stat3: "note moyenne",
  stat4: "villes couvertes",
  popular: "Recherches populaires:",
  section_how_badge: "La méthode",
  section_featured: "Les plus réservés cette semaine",
  section_featured_badge: "Véhicules à la une",
  see_all: "Voir tout →",
  view_all_cars: "Voir tous les véhicules",
  why_badge: "Pourquoi LOCCOR ?",
  why_title: "Nos garanties",
  testi_badge: "Avis clients",
  testi_title: "Ce qu'ils disent de nous",
  fleet_title: "Notre Flotte",
  fleet_sub: "Choisissez parmi 142 véhicules dans 17 villes du Maroc",
  apply_filters: "Appliquer les filtres",
  load_more: "Charger plus",
  price_range: "Prix par jour",
  about_title: "À propos",
  contact_title: "Contactez-nous",
  footer_desc: "Plateforme marocaine 100% pour la location de voitures.",
  partners_label: "Nos partenaires de confiance",
  step1_modal_title: "Vos coordonnées",
  confirm_title: "Réservation confirmée ! 🎉",
  confirm_msg1: "Vous recevrez une confirmation par WhatsApp et Email dans 5 minutes.",
  confirm_msg2: "Il s'agit d'un formulaire de démonstration – en réalité vous seriez redirigé vers la page de paiement.",
  next_step: "Suivant →",
  back: "← Retour",
  close_btn: "Fermer",
  trust1: "✅ Annulation gratuite avant 48h",
  trust2: "🔒 Paiement 100% sécurisé",
  trust3: "📞 Support 7/7 de 8h à 22h",
  trust4: "🏆 +15 000 réservations en 2024",
  step_num1: "Étape 1",
  step_num2: "Étape 2",
  step_num3: "Étape 3",
  why1_title: "Prix transparents",
  why1_desc: "Aucuns frais cachés. Le prix affiché est le prix final.",
  why2_title: "Agences fiables",
  why2_desc: "+150 agences sélectionnées et contrôlées par notre équipe.",
  why3_title: "Réservation instantanée",
  why3_desc: "Confirmation en quelques minutes. Pas d'attente, pas de complications.",
  why4_title: "Support 24/7",
  why4_desc: "Notre équipe est disponible 7j/7 pour répondre à toutes vos questions.",
  city_placeholder: "Ville ou aéroport...",
  search_label: "Rechercher",
  login_title: "Espace Professionnel",
  login_sub: "Entrez vos identifiants pour accéder au tableau de bord",
  login_user: "Nom d'utilisateur",
  login_pass: "Mot de passe",
  login_btn: "Connexion",
  login_error: "Identifiants incorrects",
  per_day: "/jour",
  reserve_btn: "Réserver",
  book_label: "Réserver maintenant",
  book_name: "Nom complet",
  book_phone: "Numéro de téléphone",
  book_email: "Email (optionnel)",
  book_notes: "Notes (optionnel)",
  payment_title: "Choisissez un mode de paiement",
  pay_card: "Carte bancaire",
  pay_virement: "Virement bancaire",
  pay_cash: "Espèces à la livraison",
  step1_error: "Veuillez saisir votre nom et numéro de téléphone",
  step2_error: "Veuillez choisir un mode de paiement",
  footer_links: "Liens rapides",
  footer_quick: "Pages",
  footer_support: "Support",
  footer_legal: "Légal",
  footer_contact_title: "Nous contacter",
  footer_rights: "Tous droits réservés",
  about_sub: "Plateforme leader de location de voitures au Maroc depuis 2020",
  about_mission_title: "Notre mission",
  about_mission_text: "Connecter les voyageurs aux meilleures agences de location du Maroc de façon transparente, sécurisée et fiable.",
  contact_sub: "Nous sommes là pour vous aider. Contactez-nous à tout moment.",
  contact_email_label: "Email",
  contact_phone_label: "Téléphone",
  contact_msg_label: "Votre message",
  contact_send: "Envoyer",
  contact_success: "Votre message a bien été envoyé ! Nous vous contacterons bientôt.",
  admin_dash: "Tableau de bord",
  admin_fleet: "Flotte",
  admin_bookings: "Réservations",
  admin_agencies: "Agences",
  admin_stats: "Statistiques",
  admin_invitations: "Invitations",
  inv_title: "Répertoire d'agences & Invitations",
  inv_sub: "Ajoutez des agences et envoyez-leur une invitation à rejoindre LOCCOR",
  inv_add_btn: "+ Ajouter une agence",
  inv_search_ph: "Rechercher une agence...",
  inv_col_agency: "Agence",
  inv_col_city: "Ville",
  inv_col_contact: "Contact",
  inv_col_status: "Statut",
  inv_col_actions: "Actions",
  inv_send: "Envoyer invitation",
  inv_resend: "Renvoyer",
  inv_status_pending: "En attente",
  inv_status_invited: "Invitée",
  inv_status_active: "Active",
  inv_status_rejected: "Refusée",
  inv_modal_title: "Ajouter une agence & envoyer une invitation",
  inv_name_ph: "Nom de l'agence",
  inv_city_ph: "Ville",
  inv_email_ph: "Adresse email",
  inv_phone_ph: "Numéro de téléphone",
  inv_msg_label: "Message d'invitation",
  inv_msg_ph: "Rédigez un message personnalisé...",
  inv_cancel: "Annuler",
  inv_confirm_send: "Ajouter & envoyer l'invitation",
  inv_sent_toast: "✅ Invitation envoyée avec succès !",
  inv_stats_total: "Total agences",
  inv_stats_invited: "Invitations envoyées",
  inv_stats_active: "Actives sur la plateforme",
  inv_stats_pending: "En attente de réponse",
  inv_filter_all: "Toutes",
};

const en: Translations = {
  nav_home: "Home",
  nav_fleet: "Our Fleet",
  nav_admin: "Partner Area",
  nav_about: "About",
  nav_contact: "Contact",
  btn_book_now: "Book Now",
  hero_badge: "🌟 #1 Platform in Morocco",
  hero_title: "Travel Free,",
  hero_subtitle: "Over 150 verified agencies · Instant booking · Free cancellation",
  btn_search: "Search",
  how_it_works: "How it works?",
  step1_title: "Choose your car",
  step1_desc: "Compare hundreds of cars from trusted and carefully selected Moroccan agencies.",
  step2_title: "Pay deposit",
  step2_desc: "Pay only 15% to secure your booking. 100% secure payment.",
  step3_title: "Drive",
  step3_desc: "Pick up the keys directly at the agency and pay the rest on site.",
  filters: "Filters",
  cat_title: "Category",
  trans_title: "Transmission",
  cars_found: "142 cars available",
  sort_price: "Lowest Price",
  sort_rating: "Highest Rated",
  sort_new: "Newest first",
  modal_title: "Booking Confirmation",
  stat1: "partner agencies",
  stat2: "successful bookings",
  stat3: "average rating",
  stat4: "cities covered",
  popular: "Popular searches:",
  section_how_badge: "The method",
  section_featured: "Most booked this week",
  section_featured_badge: "Featured vehicles",
  see_all: "See all →",
  view_all_cars: "View all cars",
  why_badge: "Why LOCCOR?",
  why_title: "Our guarantees",
  testi_badge: "Customer reviews",
  testi_title: "What they say about us",
  fleet_title: "Our Fleet",
  fleet_sub: "Choose from 142 cars in 17 Moroccan cities",
  apply_filters: "Apply filters",
  load_more: "Load more",
  price_range: "Price per day",
  about_title: "About Us",
  contact_title: "Contact Us",
  footer_desc: "100% Moroccan platform for car rental.",
  partners_label: "Our trusted partners",
  step1_modal_title: "Your personal details",
  confirm_title: "Booking confirmed! 🎉",
  confirm_msg1: "You will receive a confirmation via WhatsApp and Email within 5 minutes.",
  confirm_msg2: "This is a demo form – in reality you would be redirected to the payment page.",
  next_step: "Next →",
  back: "← Back",
  close_btn: "Close",
  trust1: "✅ Free cancellation before 48h",
  trust2: "🔒 100% secure payment",
  trust3: "📞 Support 7/7 from 8am to 10pm",
  trust4: "🏆 +15,000 bookings in 2024",
  step_num1: "Step 1",
  step_num2: "Step 2",
  step_num3: "Step 3",
  why1_title: "Transparent prices",
  why1_desc: "No hidden fees. The displayed price is the final price.",
  why2_title: "Trusted agencies",
  why2_desc: "+150 agencies selected and monitored by our team.",
  why3_title: "Instant booking",
  why3_desc: "Confirmation within minutes. No waiting, no complications.",
  why4_title: "24/7 support",
  why4_desc: "Our team is available 7 days a week to answer all your questions.",
  city_placeholder: "City or airport...",
  search_label: "Search",
  login_title: "Professional Space",
  login_sub: "Enter your credentials to access the dashboard",
  login_user: "Username",
  login_pass: "Password",
  login_btn: "Sign in",
  login_error: "Incorrect credentials",
  per_day: "/day",
  reserve_btn: "Book Now",
  book_label: "Book now",
  book_name: "Full name",
  book_phone: "Phone number",
  book_email: "Email (optional)",
  book_notes: "Notes (optional)",
  payment_title: "Choose a payment method",
  pay_card: "Credit card",
  pay_virement: "Bank transfer",
  pay_cash: "Cash on delivery",
  step1_error: "Please enter your name and phone number",
  step2_error: "Please choose a payment method",
  footer_links: "Quick links",
  footer_quick: "Pages",
  footer_support: "Support",
  footer_legal: "Legal",
  footer_contact_title: "Contact us",
  footer_rights: "All rights reserved",
  about_sub: "Morocco's leading car rental platform since 2020",
  about_mission_title: "Our mission",
  about_mission_text: "Connect travelers to the best car rental agencies in Morocco in a transparent, secure and reliable way.",
  contact_sub: "We're here to help. Contact us anytime.",
  contact_email_label: "Email",
  contact_phone_label: "Phone",
  contact_msg_label: "Your message",
  contact_send: "Send",
  contact_success: "Your message has been sent! We will contact you soon.",
  admin_dash: "Dashboard",
  admin_fleet: "Fleet",
  admin_bookings: "Bookings",
  admin_agencies: "Agencies",
  admin_stats: "Statistics",
  admin_invitations: "Invitations",
  inv_title: "Agency Directory & Invitations",
  inv_sub: "Add agencies and send them an invitation to join the LOCCOR platform",
  inv_add_btn: "+ Add agency",
  inv_search_ph: "Search for an agency...",
  inv_col_agency: "Agency",
  inv_col_city: "City",
  inv_col_contact: "Contact",
  inv_col_status: "Status",
  inv_col_actions: "Actions",
  inv_send: "Send invitation",
  inv_resend: "Resend",
  inv_status_pending: "Pending",
  inv_status_invited: "Invited",
  inv_status_active: "Active",
  inv_status_rejected: "Rejected",
  inv_modal_title: "Add agency & send invitation",
  inv_name_ph: "Agency name",
  inv_city_ph: "City",
  inv_email_ph: "Email address",
  inv_phone_ph: "Phone number",
  inv_msg_label: "Invitation message",
  inv_msg_ph: "Write a personalized message...",
  inv_cancel: "Cancel",
  inv_confirm_send: "Add & send invitation",
  inv_sent_toast: "✅ Invitation sent successfully!",
  inv_stats_total: "Total agencies",
  inv_stats_invited: "Invitations sent",
  inv_stats_active: "Active on platform",
  inv_stats_pending: "Awaiting response",
  inv_filter_all: "All",
};

export const translations: Record<Lang, Translations> = { ar, fr, en };
