import { useState, useEffect } from "react";
import { useLang } from "../context/LangContext";
import { Lang } from "../i18n";

type Page = "home" | "fleet" | "about" | "contact" | "login" | "admin";

type Props = {
  page: Page;
  setPage: (p: Page) => void;
};

export default function Header({ page, setPage }: Props) {
  const { lang, t, setLang } = useLang();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const nav = (p: Page) => {
    setPage(p);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <>
      <header
        className="sticky top-0 z-50 border-b border-[#E8BC6A]/30 text-white py-3 px-4 md:px-10 flex justify-between items-center transition-all duration-300"
        style={{
          background: scrolled ? "rgba(15,15,15,0.97)" : "#0f0f0f",
          boxShadow: scrolled ? "0 4px 24px rgba(0,0,0,.3)" : "none",
        }}
      >
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => nav("home")}>
          <div className="bg-[#E8BC6A] text-[#0f0f0f] w-10 h-10 rounded-xl flex items-center justify-center text-xl font-black shadow-lg" style={{ fontFamily: "Montserrat, sans-serif" }}>L</div>
          <div dir="ltr" className="flex flex-col leading-none">
            <span className="text-xl font-black tracking-widest text-white" style={{ fontFamily: "Montserrat, sans-serif" }}>
              LOCCOR<span className="text-[#E8BC6A]">.</span><span className="text-xs font-bold text-gray-400">COM</span>
            </span>
            <span className="text-[9px] text-gray-500 font-bold tracking-widest uppercase">Location de Voitures · Maroc</span>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-1 font-bold text-sm">
          {(["home", "fleet", "about", "contact"] as Page[]).map((p) => {
            const labels: Record<string, string> = { home: t.nav_home, fleet: t.nav_fleet, about: t.nav_about, contact: t.nav_contact };
            return (
              <button key={p} onClick={() => nav(p)}
                className={`px-4 py-2 rounded-lg transition ${page === p ? "text-[#E8BC6A]" : "hover:text-[#E8BC6A] hover:bg-white/5"}`}>
                {labels[p]}
              </button>
            );
          })}
          <button onClick={() => nav("login")}
            className="px-4 py-2 rounded-lg text-[#E8BC6A] hover:text-white border border-[#E8BC6A]/40 hover:border-[#E8BC6A] transition mx-2">
            {t.nav_admin}
          </button>
        </nav>

        <div className="flex items-center gap-2 md:gap-3">
          <select
            value={lang}
            onChange={(e) => setLang(e.target.value as Lang)}
            className="bg-[#1a1a1a] text-white border border-gray-700 rounded-lg px-2 py-1.5 text-xs outline-none cursor-pointer font-bold"
          >
            <option value="ar">🇲🇦 الدارجة</option>
            <option value="fr">🇫🇷 Français</option>
            <option value="en">🇬🇧 English</option>
          </select>
          <button
            onClick={() => nav("fleet")}
            className="hidden md:flex items-center gap-2 bg-[#E8BC6A] text-[#0f0f0f] px-5 py-2.5 rounded-xl font-black shadow hover:bg-[#f5d898] transition text-sm"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
            </svg>
            {t.btn_book_now}
          </button>
          <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden text-white p-2">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
          </button>
        </div>
      </header>

      {mobileOpen && (
        <div className="fixed top-[60px] inset-x-0 z-40 bg-[rgba(15,15,15,0.95)] backdrop-blur text-white p-4 border-b border-[#E8BC6A]/20 shadow-2xl">
          <nav className="flex flex-col gap-1">
            {(["home", "fleet", "about", "contact"] as Page[]).map((p) => {
              const labels: Record<string, string> = { home: t.nav_home, fleet: t.nav_fleet, about: t.nav_about, contact: t.nav_contact };
              return (
                <button key={p} onClick={() => nav(p)} className="text-start py-3 px-4 rounded-xl hover:bg-white/5 font-bold">{labels[p]}</button>
              );
            })}
            <div className="border-t border-white/10 mt-2 pt-2">
              <button onClick={() => nav("fleet")} className="w-full bg-[#E8BC6A] text-[#0f0f0f] py-3 rounded-xl font-black">
                {t.btn_book_now}
              </button>
            </div>
          </nav>
        </div>
      )}
    </>
  );
}
