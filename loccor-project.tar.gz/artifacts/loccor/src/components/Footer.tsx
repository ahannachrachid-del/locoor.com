import { useLang } from "../context/LangContext";

type Props = { setPage: (p: string) => void };

export default function Footer({ setPage }: Props) {
  const { t } = useLang();

  return (
    <footer className="bg-[#0f0f0f] text-white py-12 px-4">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-[#E8BC6A] text-[#0f0f0f] w-10 h-10 rounded-xl flex items-center justify-center text-xl font-black" style={{ fontFamily: "Montserrat, sans-serif" }}>L</div>
            <span className="text-xl font-black text-white" style={{ fontFamily: "Montserrat, sans-serif" }}>
              LOCCOR<span className="text-[#E8BC6A]">.</span><span className="text-xs text-gray-400">COM</span>
            </span>
          </div>
          <p className="text-gray-400 text-sm font-semibold leading-relaxed mb-4 max-w-xs">{t.footer_desc}</p>
          <div className="flex gap-3">
            {["f", "in", "tw"].map((s) => (
              <div key={s} className="w-8 h-8 bg-white/5 hover:bg-[#E8BC6A]/20 rounded-lg flex items-center justify-center cursor-pointer transition text-xs font-bold text-gray-400 hover:text-[#E8BC6A]">
                {s}
              </div>
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs font-black text-[#E8BC6A] uppercase tracking-widest mb-4">{t.footer_quick}</p>
          <div className="flex flex-col gap-2">
            {(["home", "fleet", "about", "contact"] as const).map((p) => {
              const labels: Record<string, string> = { home: t.nav_home, fleet: t.nav_fleet, about: t.nav_about, contact: t.nav_contact };
              return (
                <button key={p} onClick={() => setPage(p)} className="text-start text-sm text-gray-400 font-semibold hover:text-[#E8BC6A] transition">
                  {labels[p]}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <p className="text-xs font-black text-[#E8BC6A] uppercase tracking-widest mb-4">{t.footer_contact_title}</p>
          <div className="flex flex-col gap-2 text-sm text-gray-400 font-semibold">
            <span dir="ltr">📧 contact@loccor.com</span>
            <span dir="ltr">📞 +212 5XX-XXXXXX</span>
            <span>📍 Casablanca, Maroc</span>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row items-center justify-between gap-3">
        <p className="text-xs text-gray-500 font-bold" dir="ltr">
          © 2025 LOCCOR.COM — {t.footer_rights}
        </p>
        <div className="flex gap-4 text-xs text-gray-500 font-bold">
          <button className="hover:text-[#E8BC6A] transition">{t.footer_legal}</button>
          <button className="hover:text-[#E8BC6A] transition">{t.footer_support}</button>
        </div>
      </div>
    </footer>
  );
}
