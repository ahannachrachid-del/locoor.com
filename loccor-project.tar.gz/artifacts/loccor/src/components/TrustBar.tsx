import { useLang } from "../context/LangContext";

export default function TrustBar() {
  const { t } = useLang();
  return (
    <div className="text-white text-xs font-bold py-2 px-4 flex items-center justify-center gap-6 overflow-hidden"
      style={{ background: "linear-gradient(90deg,#0f0f0f 0%,#1a1a1a 100%)" }}>
      <span className="whitespace-nowrap">{t.trust1}</span>
      <span className="text-[#E8BC6A] hidden sm:inline">|</span>
      <span className="whitespace-nowrap hidden sm:inline">{t.trust2}</span>
      <span className="text-[#E8BC6A] hidden md:inline">|</span>
      <span className="whitespace-nowrap hidden md:inline">{t.trust3}</span>
      <span className="text-[#E8BC6A] hidden lg:inline">|</span>
      <span className="whitespace-nowrap hidden lg:inline">{t.trust4}</span>
    </div>
  );
}
