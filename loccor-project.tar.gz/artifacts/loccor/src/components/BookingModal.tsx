import { useState } from "react";
import { useLang } from "../context/LangContext";

type Props = {
  car: string;
  pricePerDay: number;
  totalPrice: number;
  onClose: () => void;
};

export default function BookingModal({ car, pricePerDay, totalPrice, onClose }: Props) {
  const { t } = useLang();
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");
  const [payment, setPayment] = useState<string | null>(null);
  const [err1, setErr1] = useState(false);
  const [err2, setErr2] = useState(false);
  const deposit = Math.round(totalPrice * 0.15);
  const ref = "LCC-2025-" + Math.random().toString(36).substring(2, 8).toUpperCase();

  const validateStep1 = () => {
    if (!name || !phone) { setErr1(true); return; }
    setErr1(false);
    setStep(2);
  };

  const validateStep2 = () => {
    if (!payment) { setErr2(true); return; }
    setErr2(false);
    setStep(3);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md relative" onClick={(e) => e.stopPropagation()}>
        <div className="bg-[#0f0f0f] text-white rounded-t-3xl px-6 py-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{t.modal_title}</p>
            <p className="font-black text-[#E8BC6A] text-lg">{car}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-2xl font-light leading-none">×</button>
        </div>

        <div className="flex gap-2 px-6 pt-4 pb-0">
          {[1, 2, 3].map((i) => (
            <div key={i} className={`h-2 flex-1 rounded-full transition-all ${step >= i ? "bg-[#E8BC6A]" : "bg-gray-200"}`} />
          ))}
        </div>

        <div className="px-6 py-4">
          {step === 1 && (
            <div>
              <p className="font-black text-[#0f0f0f] mb-4">{t.step1_modal_title}</p>
              <div className="flex flex-col gap-3">
                <input value={name} onChange={(e) => setName(e.target.value)}
                  placeholder={t.book_name}
                  className="border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-[#E8BC6A] transition" />
                <input value={phone} onChange={(e) => setPhone(e.target.value)}
                  placeholder={t.book_phone} type="tel"
                  className="border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-[#E8BC6A] transition" />
                <input value={email} onChange={(e) => setEmail(e.target.value)}
                  placeholder={t.book_email} type="email"
                  className="border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-[#E8BC6A] transition" />
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)}
                  placeholder={t.book_notes} rows={2}
                  className="border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-[#E8BC6A] transition resize-none" />
              </div>
              {err1 && <p className="text-red-500 text-xs font-bold mt-2">{t.step1_error}</p>}
              <div className="border-t mt-4 pt-3 flex items-center justify-between text-xs text-gray-500 font-bold">
                <span>Total: <span className="text-[#0f0f0f]">{totalPrice} MAD</span></span>
                <span>Acompte: <span className="text-[#E8BC6A]">{deposit} MAD</span></span>
              </div>
              <button onClick={validateStep1}
                className="w-full mt-3 bg-[#E8BC6A] text-[#0f0f0f] py-3.5 rounded-xl font-black hover:bg-[#f5d898] transition">
                {t.next_step}
              </button>
            </div>
          )}

          {step === 2 && (
            <div>
              <p className="font-black text-[#0f0f0f] mb-4">{t.payment_title}</p>
              <div className="flex flex-col gap-2">
                {[
                  { key: "card", label: t.pay_card, icon: "💳" },
                  { key: "virement", label: t.pay_virement, icon: "🏦" },
                  { key: "cash", label: t.pay_cash, icon: "💵" },
                ].map(({ key, label, icon }) => (
                  <button key={key} onClick={() => setPayment(key)}
                    className={`flex items-center gap-3 border-2 rounded-xl px-4 py-3 font-bold text-sm transition ${payment === key ? "border-[#E8BC6A] bg-[#E8BC6A]/10 text-[#0f0f0f]" : "border-gray-200 text-gray-600 hover:border-[#E8BC6A]/50"}`}>
                    <span className="text-xl">{icon}</span>{label}
                  </button>
                ))}
              </div>
              {err2 && <p className="text-red-500 text-xs font-bold mt-2">{t.step2_error}</p>}
              <div className="flex gap-2 mt-4">
                <button onClick={() => setStep(1)}
                  className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-black hover:bg-gray-200 transition text-sm">
                  {t.back}
                </button>
                <button onClick={validateStep2}
                  className="flex-[2] bg-[#E8BC6A] text-[#0f0f0f] py-3 rounded-xl font-black hover:bg-[#f5d898] transition">
                  {t.next_step}
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="text-center py-4">
              <div className="w-20 h-20 bg-green-100 text-green-500 rounded-full flex items-center justify-center text-4xl mx-auto mb-4">✓</div>
              <h3 className="text-xl font-black text-[#0f0f0f] mb-2">{t.confirm_title}</h3>
              <p className="text-xs text-gray-500 font-semibold mb-2">{t.confirm_msg1}</p>
              <p className="text-xs font-bold text-gray-400 mb-1" dir="ltr">Réf: {ref}</p>
              <p className="text-[10px] text-gray-400 font-bold mb-6">{t.confirm_msg2}</p>
              <button onClick={onClose}
                className="w-full bg-[#0f0f0f] text-white py-3.5 rounded-xl font-black hover:bg-black transition">
                {t.close_btn}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
