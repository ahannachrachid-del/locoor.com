import { useState } from "react";
import { useLang } from "../context/LangContext";
import { cars } from "../data/cars";
import BookingModal from "../components/BookingModal";

type Props = { setPage: (p: string) => void };

const CITIES_AR = ["مراكش", "الدار البيضاء", "أكادير", "طنجة", "فاس", "الرباط"];
const CITIES_FR = ["Marrakech", "Casablanca", "Agadir", "Tanger", "Fès", "Rabat"];
const CITIES_EN = ["Marrakech", "Casablanca", "Agadir", "Tangier", "Fez", "Rabat"];

const WHY_ICONS = ["💰", "🏆", "⚡", "📞"];

const TESTIMONIALS = [
  { name: "Youssef B.", city: "Casablanca", text_ar: "خدمة ممتازة! الحجز كان سهل ووصلتني السيارة في الوقت المحدد.", text_fr: "Service excellent ! La réservation était simple et la voiture était prête à l'heure.", text_en: "Excellent service! Booking was simple and the car was ready on time.", rating: 5 },
  { name: "Sophie M.", city: "Paris", text_ar: "وكالة محترفة ومصداقة. أنصح بها 100%", text_fr: "Agence très professionnelle et fiable. Je recommande à 100%", text_en: "Very professional and reliable agency. 100% recommended.", rating: 5 },
  { name: "Ahmed R.", city: "Marrakech", text_ar: "الثمن معقول والسيارة كانت نظيفة. غادي نرجع.", text_fr: "Prix raisonnable et voiture propre. Je reviendrai.", text_en: "Reasonable price and clean car. I'll be back.", rating: 4 },
];

export default function HomePage({ setPage }: Props) {
  const { t, lang } = useLang();
  const [city, setCity] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [booking, setBooking] = useState<{ car: string; price: number } | null>(null);

  const today = new Date();
  const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
  const nextWeek = new Date(today); nextWeek.setDate(today.getDate() + 6);
  const fmt = (d: Date) => d.toISOString().split("T")[0];

  const cities = lang === "ar" ? CITIES_AR : lang === "fr" ? CITIES_FR : CITIES_EN;
  const featured = cars.slice(0, 4);

  const WHY = [
    { title: t.why1_title, desc: t.why1_desc },
    { title: t.why2_title, desc: t.why2_desc },
    { title: t.why3_title, desc: t.why3_desc },
    { title: t.why4_title, desc: t.why4_desc },
  ];

  const getLocation = (car: (typeof cars)[0]) =>
    lang === "ar" ? car.location : lang === "fr" ? car.locationFr : car.locationEn;

  const days = fromDate && toDate ? Math.max(1, Math.round((new Date(toDate).getTime() - new Date(fromDate).getTime()) / 86400000)) : 5;

  return (
    <div>
      {/* HERO */}
      <section className="relative h-[640px] md:h-[720px] flex flex-col items-center justify-center bg-cover bg-center"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1502877338535-766e1452684a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80')" }}>
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top,rgba(15,15,15,1) 0%,rgba(15,15,15,.7) 35%,rgba(15,15,15,.2) 70%,rgba(15,15,15,.05) 100%)" }} />
        <div className="relative z-10 w-full max-w-5xl px-4 text-center">
          <span className="inline-flex items-center gap-1 bg-[#E8BC6A]/20 border border-[#E8BC6A]/50 text-[#E8BC6A] px-4 py-1.5 rounded-full text-xs font-black mb-5 tracking-wider">
            {t.hero_badge}
          </span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-black text-white mb-4 leading-[1.1] drop-shadow-2xl">
            {t.hero_title}<br /><span className="text-[#E8BC6A]">{lang === "ar" ? "بأحسن الأثمنة." : lang === "fr" ? "Au meilleur prix." : "At the best price."}</span>
          </h1>
          <p className="text-base md:text-xl text-gray-300 font-semibold mb-10">{t.hero_subtitle}</p>

          {/* SEARCH BOX */}
          <div className="bg-white/92 backdrop-blur-xl rounded-2xl md:rounded-3xl p-3 md:p-4 shadow-2xl border border-white/20 w-full max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row gap-2 md:gap-3">
              <div className="flex-1 flex items-center gap-2 bg-white rounded-xl px-4 border border-gray-200 focus-within:border-[#E8BC6A] transition">
                <svg className="w-5 h-5 text-[#E8BC6A] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a2 2 0 01-2.828 0l-4.243-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
                <input list="villes-list" value={city} onChange={(e) => setCity(e.target.value)}
                  placeholder={t.city_placeholder}
                  className="w-full py-3.5 font-bold text-gray-800 outline-none bg-transparent text-sm" />
                <datalist id="villes-list">{cities.map((c) => <option key={c} value={c} />)}</datalist>
              </div>
              <div className="flex items-center gap-2 bg-white rounded-xl px-4 border border-gray-200 focus-within:border-[#E8BC6A] transition md:w-44">
                <svg className="w-4 h-4 text-[#E8BC6A] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
                <input type="date" value={fromDate || fmt(tomorrow)} onChange={(e) => setFromDate(e.target.value)}
                  className="w-full py-3.5 font-bold text-gray-700 outline-none bg-transparent text-sm" />
              </div>
              <div className="flex items-center gap-2 bg-white rounded-xl px-4 border border-gray-200 focus-within:border-[#E8BC6A] transition md:w-44">
                <svg className="w-4 h-4 text-[#E8BC6A] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
                <input type="date" value={toDate || fmt(nextWeek)} onChange={(e) => setToDate(e.target.value)}
                  className="w-full py-3.5 font-bold text-gray-700 outline-none bg-transparent text-sm" />
              </div>
              <button onClick={() => setPage("fleet")}
                className="bg-[#E8BC6A] text-[#0f0f0f] px-8 py-3.5 rounded-xl font-black hover:bg-[#f5d898] transition text-base shadow-lg flex items-center justify-center gap-2">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-4.35-4.35m0 0A7 7 0 104.65 4.65a7 7 0 0011.99 11.99z"/>
                </svg>
                {t.btn_search}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 mt-4 flex-wrap">
            <span className="text-gray-400 text-xs font-bold">{t.popular}</span>
            {cities.slice(0, 4).map((c) => (
              <button key={c} onClick={() => { setCity(c); setPage("fleet"); }}
                className="bg-white/10 border border-white/20 text-white px-3 py-1 rounded-full text-xs font-bold hover:bg-[#E8BC6A] hover:text-[#0f0f0f] hover:border-[#E8BC6A] transition">
                {c}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="bg-[#0f0f0f] text-white py-6 px-4">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[{ num: "+150", label: t.stat1 }, { num: "+15K", label: t.stat2 }, { num: "4.8★", label: t.stat3 }, { num: "17", label: t.stat4 }].map(({ num, label }) => (
            <div key={label}>
              <p className="text-3xl text-[#E8BC6A] font-black" style={{ fontFamily: "Montserrat, sans-serif" }}>{num}</p>
              <p className="text-xs text-gray-400 font-bold mt-1">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="max-w-6xl mx-auto px-4 py-20 text-center">
        <span className="text-[#E8BC6A] text-xs font-black uppercase tracking-widest">{t.section_how_badge}</span>
        <h2 className="text-3xl md:text-4xl font-black text-[#0f0f0f] mt-2 mb-14">{t.how_it_works}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {[
            { icon: "🔍", num: t.step_num1, title: t.step1_title, desc: t.step1_desc },
            { icon: "💳", num: t.step_num2, title: t.step2_title, desc: t.step2_desc },
            { icon: "🔑", num: t.step_num3, title: t.step3_title, desc: t.step3_desc },
          ].map(({ icon, num, title, desc }) => (
            <div key={num} className="bg-white rounded-3xl p-8 shadow-md border border-gray-100 hover:-translate-y-2 transition-transform">
              <div className="w-14 h-14 bg-[#E8BC6A]/10 text-[#E8BC6A] rounded-2xl flex items-center justify-center text-3xl mx-auto mb-5">{icon}</div>
              <p className="text-xs font-black text-[#E8BC6A] uppercase tracking-widest mb-2">{num}</p>
              <h3 className="font-black text-lg text-[#0f0f0f] mb-3">{title}</h3>
              <p className="text-gray-500 font-semibold text-sm leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED CARS */}
      <section className="bg-white py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-end mb-10">
            <div>
              <span className="text-[#E8BC6A] text-xs font-black uppercase tracking-widest">{t.section_featured_badge}</span>
              <h2 className="text-3xl font-black text-[#0f0f0f] mt-1">{t.section_featured}</h2>
            </div>
            <button onClick={() => setPage("fleet")} className="text-sm font-black text-[#E8BC6A] hover:underline">{t.see_all}</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map((car) => (
              <div key={car.id} className="bg-[#F8F7F4] rounded-2xl overflow-hidden border border-gray-100 group transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl">
                <div className="relative bg-gray-100 h-36 overflow-hidden">
                  {car.badge && (
                    <span className="absolute top-2 end-2 z-10 bg-[#C0392B] text-white text-[10px] font-black px-2 py-0.5 rounded-full">{car.badge}</span>
                  )}
                  <img src={car.image} alt={car.name} className="w-full h-full object-contain mix-blend-multiply p-2 group-hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="p-4">
                  <p className="text-[10px] font-bold text-gray-400 mb-1">📍 {getLocation(car)}</p>
                  <h3 className="font-black text-base text-[#0f0f0f]" dir="ltr">{car.name}</h3>
                  <div className="flex items-center gap-1 my-1">
                    <span className="text-[#E8BC6A] text-xs">{"★".repeat(car.rating)}</span>
                    <span className="text-[10px] text-gray-400">({car.reviews})</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-[11px] font-bold text-gray-500 my-2">
                    <span>💺 {car.seats} {lang === "ar" ? "مقاعد" : lang === "fr" ? "places" : "seats"}</span>
                    <span>🕹️ {car.transmission}</span>
                    <span>⛽ {car.fuel}</span>
                    {car.ac && <span>❄️ {lang === "ar" ? "تكييف" : "Clim"}</span>}
                  </div>
                  <div className="border-t pt-3 flex items-end justify-between">
                    <div>
                      <span className="text-xl font-black text-[#0f0f0f]">{car.price}</span>
                      <span className="text-gray-400 text-[11px] font-bold ms-1">MAD{t.per_day}</span>
                    </div>
                    <button onClick={() => setBooking({ car: car.name, price: car.price })}
                      className="bg-[#0f0f0f] text-white px-4 py-2 rounded-xl text-xs font-black hover:bg-[#E8BC6A] hover:text-[#0f0f0f] transition">
                      {t.reserve_btn}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-10">
            <button onClick={() => setPage("fleet")}
              className="inline-flex items-center gap-2 bg-[#0f0f0f] text-white px-8 py-3.5 rounded-xl font-black hover:bg-[#E8BC6A] hover:text-[#0f0f0f] transition shadow">
              {t.view_all_cars}
            </button>
          </div>
        </div>
      </section>

      {/* WHY LOCCOR */}
      <section className="bg-[#F8F7F4] py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <span className="text-[#E8BC6A] text-xs font-black uppercase tracking-widest">{t.why_badge}</span>
          <h2 className="text-3xl md:text-4xl font-black text-[#0f0f0f] mt-2 mb-12">{t.why_title}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {WHY.map(({ title, desc }, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 text-center hover:-translate-y-1 transition-transform">
                <div className="text-3xl mb-3">{WHY_ICONS[i]}</div>
                <h3 className="font-black text-[#0f0f0f] mb-2">{title}</h3>
                <p className="text-sm text-gray-500 font-semibold leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-white py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <span className="text-[#E8BC6A] text-xs font-black uppercase tracking-widest">{t.testi_badge}</span>
          <h2 className="text-3xl md:text-4xl font-black text-[#0f0f0f] mt-2 mb-12">{t.testi_title}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((testi, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 shadow-md border border-gray-100 text-start">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-[#E8BC6A]/20 text-[#E8BC6A] flex items-center justify-center font-black text-sm">
                    {testi.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-black text-[#0f0f0f] text-sm">{testi.name}</p>
                    <p className="text-xs text-gray-400 font-bold">📍 {testi.city}</p>
                  </div>
                  <div className="ms-auto">
                    <span className="text-[#E8BC6A] text-xs">{"★".repeat(testi.rating)}</span>
                  </div>
                </div>
                <p className="text-gray-600 text-sm font-semibold leading-relaxed">
                  "{lang === "ar" ? testi.text_ar : lang === "fr" ? testi.text_fr : testi.text_en}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {booking && (
        <BookingModal car={booking.car} pricePerDay={booking.price} totalPrice={booking.price * days} onClose={() => setBooking(null)} />
      )}
    </div>
  );
}
