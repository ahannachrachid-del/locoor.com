import { useState } from "react";
import { useLang } from "../context/LangContext";
import { cars } from "../data/cars";
import BookingModal from "../components/BookingModal";

const CATEGORIES_AR = ["الكل", "اقتصادية", "مدمجة", "SUV", "سيدان"];
const CATEGORIES_FR = ["Tous", "Économique", "Compacte", "SUV", "Berline"];
const CATEGORIES_EN = ["All", "Economy", "Compact", "SUV", "Sedan"];
const CAT_MAP: Record<string, string[]> = {
  Economique: ["Economique"], Compacte: ["Compacte"], SUV: ["SUV"], Berline: ["Berline"],
  اقتصادية: ["Economique"], مدمجة: ["Compacte"], سيدان: ["Berline"],
  Economy: ["Economique"], Compact: ["Compacte"], Sedan: ["Berline"],
};

export default function FleetPage() {
  const { t, lang } = useLang();
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState(0);
  const [transFilter, setTransFilter] = useState("all");
  const [maxPrice, setMaxPrice] = useState(600);
  const [sort, setSort] = useState("price");
  const [booking, setBooking] = useState<{ car: string; price: number } | null>(null);

  const categories = lang === "ar" ? CATEGORIES_AR : lang === "fr" ? CATEGORIES_FR : CATEGORIES_EN;

  const getLocation = (car: (typeof cars)[0]) =>
    lang === "ar" ? car.location : lang === "fr" ? car.locationFr : car.locationEn;

  const filtered = cars
    .filter((car) => {
      const q = search.toLowerCase();
      const matchSearch = !q || car.name.toLowerCase().includes(q) || getLocation(car).toLowerCase().includes(q);
      const selectedCat = categories[catFilter];
      const matchCat = catFilter === 0 || (CAT_MAP[selectedCat] || []).includes(car.category);
      const matchTrans = transFilter === "all" || car.transmission.toLowerCase().includes(transFilter.toLowerCase());
      const matchPrice = car.price <= maxPrice;
      return matchSearch && matchCat && matchTrans && matchPrice;
    })
    .sort((a, b) => {
      if (sort === "price") return a.price - b.price;
      if (sort === "rating") return b.rating - a.rating;
      return b.id - a.id;
    });

  return (
    <div className="min-h-screen bg-[#F8F7F4]">
      <div className="bg-[#0f0f0f] text-white py-12 px-4 text-center">
        <h1 className="text-3xl md:text-4xl font-black mb-2">{t.fleet_title}</h1>
        <p className="text-gray-400 font-semibold">{t.fleet_sub}</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-10 flex flex-col lg:flex-row gap-8">
        {/* SIDEBAR */}
        <aside className="lg:w-72 flex-shrink-0">
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 sticky top-24">
            <h3 className="font-black text-[#0f0f0f] mb-4">{t.filters}</h3>

            <div className="mb-5">
              <input value={search} onChange={(e) => setSearch(e.target.value)}
                placeholder={t.city_placeholder}
                className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-bold outline-none focus:border-[#E8BC6A] transition" />
            </div>

            <div className="mb-5">
              <p className="text-xs font-black text-gray-500 uppercase tracking-widest mb-3">{t.cat_title}</p>
              <div className="flex flex-wrap gap-2">
                {categories.map((cat, i) => (
                  <button key={i} onClick={() => setCatFilter(i)}
                    className={`px-3 py-1 rounded-full text-xs font-bold transition ${catFilter === i ? "bg-[#0f0f0f] text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-5">
              <p className="text-xs font-black text-gray-500 uppercase tracking-widest mb-3">{t.trans_title}</p>
              <div className="flex flex-wrap gap-2">
                {[
                  { key: "all", label: lang === "ar" ? "الكل" : lang === "fr" ? "Tous" : "All" },
                  { key: "manuelle", label: lang === "ar" ? "عادية" : "Manuelle" },
                  { key: "automatique", label: lang === "ar" ? "أوتوماتيك" : "Automatique" },
                ].map(({ key, label }) => (
                  <button key={key} onClick={() => setTransFilter(key)}
                    className={`px-3 py-1 rounded-full text-xs font-bold transition ${transFilter === key ? "bg-[#0f0f0f] text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-5">
              <p className="text-xs font-black text-gray-500 uppercase tracking-widest mb-2">{t.price_range}</p>
              <input type="range" min={100} max={600} value={maxPrice} onChange={(e) => setMaxPrice(+e.target.value)}
                className="w-full accent-[#E8BC6A]" />
              <div className="flex justify-between text-xs font-bold text-gray-500 mt-1">
                <span>100 MAD</span>
                <span className="text-[#E8BC6A] font-black">{maxPrice} MAD</span>
              </div>
            </div>
          </div>
        </aside>

        {/* MAIN */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
            <p className="font-bold text-gray-600 text-sm">
              <span className="text-[#0f0f0f] font-black">{filtered.length}</span>&nbsp;
              {lang === "ar" ? "سيارة متاحة" : lang === "fr" ? "véhicules disponibles" : "cars available"}
            </p>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-gray-500">{lang === "ar" ? "ترتيب:" : "Trier:"}</span>
              {[
                { key: "price", label: t.sort_price },
                { key: "rating", label: t.sort_rating },
                { key: "new", label: t.sort_new },
              ].map(({ key, label }) => (
                <button key={key} onClick={() => setSort(key)}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition ${sort === key ? "bg-[#0f0f0f] text-white" : "bg-white border border-gray-200 text-gray-600 hover:border-[#E8BC6A]"}`}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
            {filtered.map((car) => (
              <div key={car.id} className="bg-white rounded-2xl overflow-hidden border border-gray-100 group hover:-translate-y-1.5 hover:shadow-xl transition-all duration-300">
                <div className="relative bg-gray-50 h-40 overflow-hidden">
                  {car.badge && (
                    <span className="absolute top-2 end-2 z-10 bg-[#C0392B] text-white text-[10px] font-black px-2 py-0.5 rounded-full">{car.badge}</span>
                  )}
                  <img src={car.image} alt={car.name} className="w-full h-full object-contain p-3 mix-blend-multiply group-hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="p-4">
                  <p className="text-[10px] font-bold text-gray-400 mb-1">📍 {getLocation(car)}</p>
                  <h3 className="font-black text-base text-[#0f0f0f]" dir="ltr">{car.name}</h3>
                  <div className="flex items-center gap-1 my-1">
                    <span className="text-[#E8BC6A] text-xs">{"★".repeat(car.rating)}</span>
                    <span className="text-[10px] text-gray-400">({car.reviews})</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-[11px] font-bold text-gray-500 my-2">
                    <span>💺 {car.seats} {lang === "ar" ? "مقاعد" : lang === "fr" ? "places" : "seats"}</span>
                    <span>🕹️ {car.transmission}</span>
                    <span>⛽ {car.fuel}</span>
                    {car.ac && <span>❄️ {lang === "ar" ? "تكييف" : "Clim"}</span>}
                  </div>
                  <div className="border-t pt-3 flex items-end justify-between">
                    <div>
                      <span className="text-xl font-black text-[#0f0f0f]">{car.price}</span>
                      <span className="text-gray-400 text-[11px] font-bold ms-1">MAD{t.per_day}</span>
                    </div>
                    <button onClick={() => setBooking({ car: car.name, price: car.price })}
                      className="bg-[#0f0f0f] text-white px-4 py-2 rounded-xl text-xs font-black hover:bg-[#E8BC6A] hover:text-[#0f0f0f] transition">
                      {t.reserve_btn}
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {filtered.length === 0 && (
              <div className="col-span-full text-center py-20 text-gray-400 font-bold">
                {lang === "ar" ? "لا توجد سيارات متاحة" : lang === "fr" ? "Aucun véhicule disponible" : "No cars available"}
              </div>
            )}
          </div>
        </div>
      </div>

      {booking && (
        <BookingModal car={booking.car} pricePerDay={booking.price} totalPrice={booking.price * 5} onClose={() => setBooking(null)} />
      )}
    </div>
  );
}
