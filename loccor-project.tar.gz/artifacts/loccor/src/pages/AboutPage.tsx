import { useLang } from "../context/LangContext";

export default function AboutPage() {
  const { t } = useLang();

  const team = [
    { name: "Karim Alami", role: "CEO & Fondateur", img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80" },
    { name: "Nadia Benali", role: "Directrice Opérations", img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80" },
    { name: "Omar Tahiri", role: "Responsable Tech", img: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80" },
  ];

  const stats = [
    { num: "+150", label: t.stat1 },
    { num: "+15K", label: t.stat2 },
    { num: "4.8★", label: t.stat3 },
    { num: "17", label: t.stat4 },
  ];

  return (
    <div className="min-h-screen bg-[#F8F7F4]">
      <div className="bg-[#0f0f0f] text-white py-16 px-4 text-center">
        <h1 className="text-3xl md:text-5xl font-black mb-3">{t.about_title}</h1>
        <p className="text-gray-400 font-semibold max-w-xl mx-auto">{t.about_sub}</p>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-16">
        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-gray-100 mb-10">
          <div className="w-16 h-16 bg-[#E8BC6A]/10 text-[#E8BC6A] rounded-2xl flex items-center justify-center text-3xl mb-6">🎯</div>
          <h2 className="text-2xl font-black text-[#0f0f0f] mb-4">{t.about_mission_title}</h2>
          <p className="text-gray-600 text-lg leading-relaxed font-semibold">{t.about_mission_text}</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
          {stats.map(({ num, label }) => (
            <div key={label} className="bg-white rounded-2xl p-6 text-center shadow-sm border border-gray-100">
              <p className="text-3xl font-black text-[#E8BC6A]" style={{ fontFamily: "Montserrat, sans-serif" }}>{num}</p>
              <p className="text-xs text-gray-500 font-bold mt-1">{label}</p>
            </div>
          ))}
        </div>

        <h2 className="text-2xl font-black text-[#0f0f0f] mb-6 text-center">
          {t.lang === "ar" ? "فريقنا" : "Notre équipe"}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {team.map((member) => (
            <div key={member.name} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 text-center">
              <img src={member.img} alt={member.name} className="w-full h-48 object-cover" />
              <div className="p-5">
                <h3 className="font-black text-[#0f0f0f]">{member.name}</h3>
                <p className="text-sm text-gray-500 font-semibold mt-1">{member.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
