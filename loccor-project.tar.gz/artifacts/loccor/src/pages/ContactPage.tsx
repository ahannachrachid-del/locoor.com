import { useState } from "react";
import { useLang } from "../context/LangContext";

export default function ContactPage() {
  const { t } = useLang();
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [msg, setMsg] = useState("");
  const [success, setSuccess] = useState(false);

  const send = () => {
    setSuccess(true);
    setEmail(""); setPhone(""); setMsg("");
    setTimeout(() => setSuccess(false), 4000);
  };

  return (
    <div className="min-h-screen bg-[#F8F7F4]">
      <div className="bg-[#0f0f0f] text-white py-16 px-4 text-center">
        <h1 className="text-3xl md:text-5xl font-black mb-3">{t.contact_title}</h1>
        <p className="text-gray-400 font-semibold max-w-xl mx-auto">{t.contact_sub}</p>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-16 grid md:grid-cols-2 gap-10">
        <div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-[#E8BC6A]/10 text-[#E8BC6A] rounded-xl flex items-center justify-center text-xl">📧</div>
              <div>
                <p className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.contact_email_label}</p>
                <p className="font-black text-[#0f0f0f]" dir="ltr">contact@loccor.com</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-[#E8BC6A]/10 text-[#E8BC6A] rounded-xl flex items-center justify-center text-xl">📞</div>
              <div>
                <p className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.contact_phone_label}</p>
                <p className="font-black text-[#0f0f0f]" dir="ltr">+212 5XX-XXXXXX</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-[#E8BC6A]/10 text-[#E8BC6A] rounded-xl flex items-center justify-center text-xl">🕐</div>
              <div>
                <p className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.trust3.replace("📞 ", "")}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
          <div className="flex flex-col gap-4">
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email"
              placeholder={t.contact_email_label}
              className="border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-[#E8BC6A] transition" />
            <input value={phone} onChange={(e) => setPhone(e.target.value)} type="tel"
              placeholder={t.contact_phone_label}
              className="border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-[#E8BC6A] transition" />
            <textarea value={msg} onChange={(e) => setMsg(e.target.value)} rows={5}
              placeholder={t.contact_msg_label}
              className="border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-[#E8BC6A] transition resize-none" />
            <button onClick={send}
              className="w-full bg-[#E8BC6A] text-[#0f0f0f] py-3.5 rounded-xl font-black hover:bg-[#f5d898] transition">
              {t.contact_send}
            </button>
            {success && (
              <div className="bg-green-50 border border-green-200 text-green-700 rounded-xl px-4 py-3 text-sm font-bold text-center">
                {t.contact_success}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
