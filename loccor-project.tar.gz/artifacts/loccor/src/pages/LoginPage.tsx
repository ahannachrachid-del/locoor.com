import { useState } from "react";
import { useLang } from "../context/LangContext";

type Props = { setPage: (p: string) => void };

export default function LoginPage({ setPage }: Props) {
  const { t } = useLang();
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState(false);

  const login = () => {
    if ((user === "admin" || user === "") && pass === "admin2026") {
      setError(false);
      setPage("admin");
    } else {
      setError(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F7F4] flex items-center justify-center px-4">
      <div className="bg-white rounded-3xl shadow-xl border border-gray-100 w-full max-w-sm p-8">
        <div className="text-center mb-8">
          <div className="bg-[#E8BC6A] text-[#0f0f0f] w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-black mx-auto mb-4" style={{ fontFamily: "Montserrat, sans-serif" }}>L</div>
          <h1 className="text-xl font-black text-[#0f0f0f]">{t.login_title}</h1>
          <p className="text-sm text-gray-500 font-semibold mt-1">{t.login_sub}</p>
        </div>

        <div className="flex flex-col gap-4">
          <input value={user} onChange={(e) => setUser(e.target.value)}
            placeholder={t.login_user}
            className="border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-[#E8BC6A] transition" />
          <input value={pass} onChange={(e) => setPass(e.target.value)} type="password"
            placeholder={t.login_pass}
            onKeyDown={(e) => e.key === "Enter" && login()}
            className="border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-[#E8BC6A] transition" />
          {error && <p className="text-red-500 text-xs font-bold text-center">{t.login_error}</p>}
          <button onClick={login}
            className="w-full bg-[#0f0f0f] text-white py-3.5 rounded-xl font-black hover:bg-[#E8BC6A] hover:text-[#0f0f0f] transition">
            {t.login_btn}
          </button>
        </div>
        <p className="text-center text-[10px] text-gray-400 font-bold mt-4" dir="ltr">admin / admin2026</p>
      </div>
    </div>
  );
}
