import { useState } from "react";
import { useLang } from "../context/LangContext";
import { cars } from "../data/cars";

type Tab = "dash" | "fleet" | "bookings" | "agencies" | "stats" | "invitations";
type InvStatus = "pending" | "invited" | "active" | "rejected";

type Agency = {
  id: number;
  name: string;
  city: string;
  email: string;
  phone: string;
  status: InvStatus;
  sentAt?: string;
};

type Props = { setPage: (p: string) => void };

const BOOKINGS = [
  { ref: "LCC-2025-A1B2C", client: "Youssef Benali", car: "Dacia Logan", city: "Casablanca", days: 5, total: 900, status: "confirmed" },
  { ref: "LCC-2025-D3E4F", client: "Sophie Martin", car: "Renault Clio", city: "Marrakech", days: 7, total: 1540, status: "pending" },
  { ref: "LCC-2025-G5H6I", client: "Ahmed Radi", car: "Toyota Corolla", city: "Rabat", days: 3, total: 960, status: "confirmed" },
  { ref: "LCC-2025-J7K8L", client: "Fatima Zahra", car: "Kia Sportage", city: "Agadir", days: 10, total: 4200, status: "cancelled" },
];

const INITIAL_AGENCIES: Agency[] = [
  { id: 1, name: "Auto Prestige Maroc", city: "Casablanca", email: "contact@autoprestige.ma", phone: "+212 6 00 11 22 33", status: "active", sentAt: "12 Jan 2025" },
  { id: 2, name: "Royal Cars Marrakech", city: "Marrakech", email: "royal@cars-marrakech.ma", phone: "+212 6 11 22 33 44", status: "invited", sentAt: "18 Fév 2025" },
  { id: 3, name: "Atlas Location Fès", city: "Fès", email: "atlas@location-fes.ma", phone: "+212 5 35 00 11 22", status: "pending" },
  { id: 4, name: "Sahara Drive Agadir", city: "Agadir", email: "info@saharadrive.ma", phone: "+212 6 22 33 44 55", status: "invited", sentAt: "3 Mar 2025" },
  { id: 5, name: "Oasis Motors Rabat", city: "Rabat", email: "oasis@motors-rabat.ma", phone: "+212 6 33 44 55 66", status: "active", sentAt: "25 Jan 2025" },
  { id: 6, name: "Nord Rent Tanger", city: "Tanger", email: "nordrent@tanger.ma", phone: "+212 6 44 55 66 77", status: "rejected" },
  { id: 7, name: "Drive Easy Agadir", city: "Agadir", email: "driveeasy@agadir.ma", phone: "+212 6 55 66 77 88", status: "pending" },
  { id: 8, name: "Médina Cars Fès", city: "Fès", email: "medina@cars-fes.ma", phone: "+212 5 35 88 99 00", status: "pending" },
];

const DEFAULT_MSG_FR = `Bonjour,

Nous avons le plaisir de vous inviter à rejoindre LOCCOR.COM, la plateforme n°1 de location de voitures au Maroc.

En rejoignant notre réseau, vous bénéficierez de :
• Une visibilité accrue auprès de milliers de clients
• Un tableau de bord simple pour gérer vos réservations
• Des paiements sécurisés et transparents

Pour créer votre compte gratuitement, cliquez sur le lien ci-dessous.

Cordialement,
L'équipe LOCCOR`;

const DEFAULT_MSG_AR = `السلام عليكم،

يسعدنا دعوتكم للانضمام إلى منصة LOCCOR.COM، المنصة الأولى لتأجير السيارات في المغرب.

بالانضمام إلى شبكتنا، ستستفيدون من:
• ظهور واسع أمام آلاف العملاء
• لوحة تحكم بسيطة لإدارة الحجوزات
• مدفوعات آمنة وشفافة

لإنشاء حسابكم مجانًا، انقروا على الرابط أدناه.

مع التحية،
فريق LOCCOR`;

export default function AdminPage({ setPage }: Props) {
  const { t, lang } = useLang();
  const [tab, setTab] = useState<Tab>("invitations");

  // Invitations state
  const [agencies, setAgencies] = useState<Agency[]>(INITIAL_AGENCIES);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<InvStatus | "all">("all");
  const [showModal, setShowModal] = useState(false);
  const [toast, setToast] = useState("");

  // Modal form state
  const [fName, setFName] = useState("");
  const [fCity, setFCity] = useState("");
  const [fEmail, setFEmail] = useState("");
  const [fPhone, setFPhone] = useState("");
  const [fMsg, setFMsg] = useState(lang === "ar" ? DEFAULT_MSG_AR : DEFAULT_MSG_FR);
  const [fErr, setFErr] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);

  const statusColor: Record<string, string> = {
    confirmed: "bg-green-100 text-green-700",
    pending: "bg-yellow-100 text-yellow-700",
    cancelled: "bg-red-100 text-red-700",
  };
  const statusLabel: Record<string, Record<string, string>> = {
    confirmed: { ar: "مؤكد", fr: "Confirmé", en: "Confirmed" },
    pending: { ar: "معلق", fr: "En attente", en: "Pending" },
    cancelled: { ar: "ملغى", fr: "Annulé", en: "Cancelled" },
  };

  const invStatusColor: Record<InvStatus, string> = {
    pending: "bg-gray-700/50 text-gray-300",
    invited: "bg-blue-900/50 text-blue-300",
    active: "bg-green-900/50 text-green-300",
    rejected: "bg-red-900/50 text-red-300",
  };
  const invStatusLabel = (s: InvStatus) => ({
    pending: t.inv_status_pending,
    invited: t.inv_status_invited,
    active: t.inv_status_active,
    rejected: t.inv_status_rejected,
  }[s]);

  const filteredAgencies = agencies.filter((a) => {
    const q = search.toLowerCase();
    const matchQ = !q || a.name.toLowerCase().includes(q) || a.city.toLowerCase().includes(q) || a.email.toLowerCase().includes(q);
    const matchS = statusFilter === "all" || a.status === statusFilter;
    return matchQ && matchS;
  });

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(""), 3000);
  };

  const openAddModal = () => {
    setFName(""); setFCity(""); setFEmail(""); setFPhone("");
    setFMsg(lang === "ar" ? DEFAULT_MSG_AR : DEFAULT_MSG_FR);
    setFErr(false); setEditId(null);
    setShowModal(true);
  };

  const openSendModal = (agency: Agency) => {
    setFName(agency.name); setFCity(agency.city);
    setFEmail(agency.email); setFPhone(agency.phone);
    setFMsg(lang === "ar" ? DEFAULT_MSG_AR : DEFAULT_MSG_FR);
    setFErr(false); setEditId(agency.id);
    setShowModal(true);
  };

  const submitInvitation = () => {
    if (!fName || !fEmail) { setFErr(true); return; }
    const now = new Date().toLocaleDateString("fr-MA", { day: "numeric", month: "short", year: "numeric" });
    if (editId !== null) {
      setAgencies((prev) => prev.map((a) => a.id === editId ? { ...a, status: "invited", sentAt: now } : a));
    } else {
      const newId = Date.now();
      setAgencies((prev) => [...prev, { id: newId, name: fName, city: fCity, email: fEmail, phone: fPhone, status: "invited", sentAt: now }]);
    }
    setShowModal(false);
    showToast(t.inv_sent_toast);
  };

  const navItems: { key: Tab; icon: string; label: string }[] = [
    { key: "dash", icon: "📊", label: t.admin_dash },
    { key: "fleet", icon: "🚗", label: t.admin_fleet },
    { key: "bookings", icon: "📋", label: t.admin_bookings },
    { key: "agencies", icon: "🏢", label: t.admin_agencies },
    { key: "invitations", icon: "✉️", label: t.admin_invitations },
    { key: "stats", icon: "📈", label: t.admin_stats },
  ];

  const invStats = {
    total: agencies.length,
    invited: agencies.filter((a) => a.status === "invited").length,
    active: agencies.filter((a) => a.status === "active").length,
    pending: agencies.filter((a) => a.status === "pending").length,
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f] flex">
      {/* SIDEBAR */}
      <aside className="w-60 flex-shrink-0 bg-[#1a1a1a] border-e border-white/10 p-4 flex-col gap-1 hidden md:flex">
        <div className="flex items-center gap-2 px-3 py-4 mb-4">
          <div className="bg-[#E8BC6A] text-[#0f0f0f] w-8 h-8 rounded-lg flex items-center justify-center text-sm font-black" style={{ fontFamily: "Montserrat, sans-serif" }}>L</div>
          <span className="text-white font-black text-sm" style={{ fontFamily: "Montserrat, sans-serif" }}>LOCCOR <span className="text-[#E8BC6A]">PRO</span></span>
        </div>
        {navItems.map(({ key, icon, label }) => (
          <button key={key} onClick={() => setTab(key)}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl font-bold text-sm transition ${tab === key ? "bg-[#E8BC6A]/15 text-[#E8BC6A]" : "text-gray-400 hover:bg-white/5 hover:text-white"}`}>
            <span>{icon}</span>{label}
            {key === "invitations" && invStats.pending > 0 && (
              <span className="ms-auto bg-[#E8BC6A] text-[#0f0f0f] text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center">{invStats.pending}</span>
            )}
          </button>
        ))}
        <div className="mt-auto">
          <button onClick={() => setPage("home")}
            className="flex items-center gap-2 px-3 py-2.5 text-gray-500 hover:text-red-400 font-bold text-sm transition w-full rounded-xl hover:bg-white/5">
            ← {lang === "ar" ? "خروج" : lang === "fr" ? "Déconnexion" : "Logout"}
          </button>
        </div>
      </aside>

      {/* MAIN */}
      <div className="flex-1 text-white overflow-auto relative">
        {/* Toast */}
        {toast && (
          <div className="fixed top-4 end-4 z-50 bg-green-800 text-white px-5 py-3 rounded-xl font-bold shadow-2xl text-sm animate-pulse">
            {toast}
          </div>
        )}

        <div className="p-4 md:p-6">
          {/* Mobile nav */}
          <div className="flex gap-2 mb-6 overflow-x-auto md:hidden pb-1">
            {navItems.map(({ key, icon, label }) => (
              <button key={key} onClick={() => setTab(key)}
                className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs transition ${tab === key ? "bg-[#E8BC6A] text-[#0f0f0f]" : "bg-white/10 text-gray-300"}`}>
                {icon} {label}
              </button>
            ))}
          </div>

          {/* ── INVITATIONS TAB ── */}
          {tab === "invitations" && (
            <div>
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-6">
                <div>
                  <h2 className="text-2xl font-black">{t.inv_title}</h2>
                  <p className="text-gray-400 text-sm font-semibold mt-1">{t.inv_sub}</p>
                </div>
                <button onClick={openAddModal}
                  className="flex-shrink-0 bg-[#E8BC6A] text-[#0f0f0f] px-5 py-2.5 rounded-xl font-black hover:bg-[#f5d898] transition text-sm">
                  {t.inv_add_btn}
                </button>
              </div>

              {/* Stats row */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
                {[
                  { label: t.inv_stats_total, value: invStats.total, color: "text-white", icon: "🏢" },
                  { label: t.inv_stats_invited, value: invStats.invited, color: "text-blue-300", icon: "📨" },
                  { label: t.inv_stats_active, value: invStats.active, color: "text-green-300", icon: "✅" },
                  { label: t.inv_stats_pending, value: invStats.pending, color: "text-yellow-300", icon: "⏳" },
                ].map(({ label, value, color, icon }) => (
                  <div key={label} className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-4">
                    <p className="text-xl mb-0.5">{icon}</p>
                    <p className={`text-2xl font-black ${color}`} style={{ fontFamily: "Montserrat, sans-serif" }}>{value}</p>
                    <p className="text-[11px] text-gray-400 font-bold">{label}</p>
                  </div>
                ))}
              </div>

              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-3 mb-5">
                <input value={search} onChange={(e) => setSearch(e.target.value)}
                  placeholder={t.inv_search_ph}
                  className="flex-1 bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2.5 text-sm font-bold text-white outline-none focus:border-[#E8BC6A] transition placeholder:text-gray-600" />
                <div className="flex gap-2 flex-wrap">
                  {(["all", "pending", "invited", "active", "rejected"] as const).map((s) => (
                    <button key={s} onClick={() => setStatusFilter(s)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${statusFilter === s ? "bg-[#E8BC6A] text-[#0f0f0f]" : "bg-white/5 text-gray-400 hover:bg-white/10"}`}>
                      {s === "all" ? t.inv_filter_all : invStatusLabel(s as InvStatus)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Table */}
              <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-gray-400 text-xs font-bold border-b border-white/10 bg-white/5">
                        <th className="py-3 px-4 text-start">{t.inv_col_agency}</th>
                        <th className="py-3 px-4 text-start">{t.inv_col_city}</th>
                        <th className="py-3 px-4 text-start">{t.inv_col_contact}</th>
                        <th className="py-3 px-4 text-start">{t.inv_col_status}</th>
                        <th className="py-3 px-4 text-start">{t.inv_col_actions}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredAgencies.map((agency) => (
                        <tr key={agency.id} className="border-b border-white/5 hover:bg-white/3 transition group">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 bg-[#E8BC6A]/15 text-[#E8BC6A] rounded-lg flex items-center justify-center font-black text-xs flex-shrink-0">
                                {agency.name.charAt(0)}
                              </div>
                              <span className="font-bold text-white">{agency.name}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-gray-300 font-semibold text-sm">
                            📍 {agency.city}
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex flex-col gap-0.5">
                              <span className="text-gray-300 text-xs font-bold" dir="ltr">{agency.email}</span>
                              <span className="text-gray-500 text-xs font-bold" dir="ltr">{agency.phone}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex flex-col gap-1">
                              <span className={`px-2.5 py-1 rounded-lg text-[11px] font-black inline-block ${invStatusColor[agency.status]}`}>
                                {invStatusLabel(agency.status)}
                              </span>
                              {agency.sentAt && (
                                <span className="text-[10px] text-gray-500 font-bold">{agency.sentAt}</span>
                              )}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            {agency.status === "pending" ? (
                              <button onClick={() => openSendModal(agency)}
                                className="bg-[#E8BC6A] text-[#0f0f0f] px-3 py-1.5 rounded-lg text-xs font-black hover:bg-[#f5d898] transition">
                                {t.inv_send}
                              </button>
                            ) : agency.status === "invited" ? (
                              <button onClick={() => openSendModal(agency)}
                                className="bg-white/10 text-gray-300 px-3 py-1.5 rounded-lg text-xs font-black hover:bg-white/20 transition">
                                {t.inv_resend}
                              </button>
                            ) : agency.status === "active" ? (
                              <span className="text-green-400 text-xs font-black">✓ {t.inv_status_active}</span>
                            ) : (
                              <button onClick={() => openSendModal(agency)}
                                className="bg-white/5 text-gray-500 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-white/10 transition">
                                {t.inv_resend}
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                      {filteredAgencies.length === 0 && (
                        <tr>
                          <td colSpan={5} className="text-center py-12 text-gray-500 font-bold">
                            {lang === "ar" ? "لا توجد نتائج" : lang === "fr" ? "Aucun résultat" : "No results found"}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ── DASHBOARD TAB ── */}
          {tab === "dash" && (
            <div>
              <h2 className="text-2xl font-black mb-6">{t.admin_dash}</h2>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                {[
                  { label: lang === "ar" ? "الحجوزات الكلية" : lang === "fr" ? "Réservations totales" : "Total bookings", value: "1,247", icon: "📋" },
                  { label: lang === "ar" ? "الإيرادات" : lang === "fr" ? "Revenus" : "Revenue", value: "248K MAD", icon: "💰" },
                  { label: lang === "ar" ? "الوكالات" : lang === "fr" ? "Agences" : "Agencies", value: "152", icon: "🏢" },
                  { label: lang === "ar" ? "التقييم" : lang === "fr" ? "Note" : "Rating", value: "4.8 ★", icon: "⭐" },
                ].map(({ label, value, icon }) => (
                  <div key={label} className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5">
                    <p className="text-2xl mb-1">{icon}</p>
                    <p className="text-2xl font-black text-[#E8BC6A]" style={{ fontFamily: "Montserrat, sans-serif" }}>{value}</p>
                    <p className="text-xs text-gray-400 font-bold mt-1">{label}</p>
                  </div>
                ))}
              </div>
              <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5">
                <h3 className="font-black text-[#E8BC6A] mb-4 text-sm uppercase tracking-widest">
                  {lang === "ar" ? "آخر الحجوزات" : lang === "fr" ? "Dernières réservations" : "Recent bookings"}
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-gray-400 text-xs font-bold border-b border-white/10">
                        <th className="py-2 text-start">Réf</th>
                        <th className="py-2 text-start">{lang === "ar" ? "العميل" : "Client"}</th>
                        <th className="py-2 text-start">{lang === "ar" ? "السيارة" : "Voiture"}</th>
                        <th className="py-2 text-start">{lang === "ar" ? "المبلغ" : "Montant"}</th>
                        <th className="py-2 text-start">{lang === "ar" ? "الحالة" : "Statut"}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {BOOKINGS.map((b) => (
                        <tr key={b.ref} className="border-b border-white/5 hover:bg-white/5 transition">
                          <td className="py-2.5 text-gray-400 text-xs font-mono" dir="ltr">{b.ref}</td>
                          <td className="py-2.5 font-bold">{b.client}</td>
                          <td className="py-2.5 text-gray-300 font-semibold">{b.car}</td>
                          <td className="py-2.5 font-black text-[#E8BC6A]">{b.total} MAD</td>
                          <td className="py-2.5">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${statusColor[b.status]}`}>
                              {statusLabel[b.status][lang]}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ── FLEET TAB ── */}
          {tab === "fleet" && (
            <div>
              <h2 className="text-2xl font-black mb-6">{t.admin_fleet}</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {cars.map((car) => (
                  <div key={car.id} className="bg-[#1a1a1a] border border-white/10 rounded-2xl overflow-hidden">
                    <img src={car.image} alt={car.name} className="w-full h-32 object-contain p-3 bg-gray-100/10 mix-blend-luminosity" />
                    <div className="p-4">
                      <h3 className="font-black" dir="ltr">{car.name}</h3>
                      <p className="text-gray-400 text-xs font-bold mt-1">📍 {car.locationFr}</p>
                      <div className="flex items-center justify-between mt-3">
                        <span className="text-[#E8BC6A] font-black">{car.price} MAD/j</span>
                        <span className="text-[10px] bg-green-900/40 text-green-400 font-black px-2 py-0.5 rounded-full">✓ Actif</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── BOOKINGS TAB ── */}
          {tab === "bookings" && (
            <div>
              <h2 className="text-2xl font-black mb-6">{t.admin_bookings}</h2>
              <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5 overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-gray-400 text-xs font-bold border-b border-white/10">
                      <th className="py-2 text-start">Réf</th>
                      <th className="py-2 text-start">Client</th>
                      <th className="py-2 text-start">Voiture</th>
                      <th className="py-2 text-start">Ville</th>
                      <th className="py-2 text-start">Jours</th>
                      <th className="py-2 text-start">Total</th>
                      <th className="py-2 text-start">Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {BOOKINGS.map((b) => (
                      <tr key={b.ref} className="border-b border-white/5 hover:bg-white/5 transition">
                        <td className="py-2.5 text-gray-400 text-xs font-mono" dir="ltr">{b.ref}</td>
                        <td className="py-2.5 font-bold">{b.client}</td>
                        <td className="py-2.5 text-gray-300">{b.car}</td>
                        <td className="py-2.5 text-gray-300">{b.city}</td>
                        <td className="py-2.5 text-center">{b.days}</td>
                        <td className="py-2.5 font-black text-[#E8BC6A]">{b.total} MAD</td>
                        <td className="py-2.5">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${statusColor[b.status]}`}>
                            {statusLabel[b.status][lang]}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ── AGENCIES TAB ── */}
          {tab === "agencies" && (
            <div>
              <h2 className="text-2xl font-black mb-6">{t.admin_agencies}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {agencies.filter((a) => a.status === "active").map((agency, i) => (
                  <div key={agency.id} className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 bg-[#E8BC6A]/20 text-[#E8BC6A] rounded-xl flex items-center justify-center font-black text-lg">🏢</div>
                      <div>
                        <p className="font-black">{agency.name}</p>
                        <p className="text-xs text-gray-400 font-bold">4.{7 + (i % 2)} ★ · {agency.city}</p>
                      </div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-400 font-bold">
                      <span dir="ltr">{agency.phone}</span>
                      <span className="text-green-400">● Actif</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── STATS TAB ── */}
          {tab === "stats" && (
            <div>
              <h2 className="text-2xl font-black mb-6">{t.admin_stats}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5">
                  <h3 className="font-black text-[#E8BC6A] mb-4 text-sm">
                    {lang === "ar" ? "الحجوزات الشهرية" : lang === "fr" ? "Réservations mensuelles" : "Monthly bookings"}
                  </h3>
                  <div className="flex items-end gap-2 h-32">
                    {[45, 72, 58, 90, 110, 95, 130, 115, 140, 125, 160, 145].map((val, i) => (
                      <div key={i} className="flex-1 bg-[#E8BC6A]/80 rounded-t-sm hover:bg-[#E8BC6A] transition"
                        style={{ height: `${(val / 160) * 100}%` }} />
                    ))}
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-500 font-bold mt-2">
                    <span>Jan</span><span>Avr</span><span>Juil</span><span>Oct</span><span>Déc</span>
                  </div>
                </div>
                <div className="bg-[#1a1a1a] border border-white/10 rounded-2xl p-5">
                  <h3 className="font-black text-[#E8BC6A] mb-4 text-sm">
                    {lang === "ar" ? "توزيع السيارات" : lang === "fr" ? "Répartition des véhicules" : "Fleet breakdown"}
                  </h3>
                  <div className="flex flex-col gap-3">
                    {[
                      { label: "Économique", pct: 38 },
                      { label: "Compacte", pct: 27 },
                      { label: "SUV", pct: 22 },
                      { label: "Berline", pct: 13 },
                    ].map(({ label, pct }) => (
                      <div key={label}>
                        <div className="flex justify-between text-xs font-bold mb-1">
                          <span className="text-gray-300">{label}</span>
                          <span className="text-[#E8BC6A]">{pct}%</span>
                        </div>
                        <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                          <div className="h-full bg-[#E8BC6A] rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── INVITATION MODAL ── */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={() => setShowModal(false)}>
          <div className="bg-[#1a1a1a] border border-white/10 rounded-3xl shadow-2xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-6 py-5 border-b border-white/10">
              <h3 className="font-black text-white text-lg">{t.inv_modal_title}</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-white text-2xl font-light">×</button>
            </div>
            <div className="p-6 flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-3">
                <input value={fName} onChange={(e) => setFName(e.target.value)}
                  placeholder={t.inv_name_ph}
                  className="bg-[#0f0f0f] border border-white/10 rounded-xl px-4 py-3 text-sm font-bold text-white outline-none focus:border-[#E8BC6A] transition placeholder:text-gray-600 col-span-2" />
                <input value={fCity} onChange={(e) => setFCity(e.target.value)}
                  placeholder={t.inv_city_ph}
                  className="bg-[#0f0f0f] border border-white/10 rounded-xl px-4 py-3 text-sm font-bold text-white outline-none focus:border-[#E8BC6A] transition placeholder:text-gray-600" />
                <input value={fPhone} onChange={(e) => setFPhone(e.target.value)}
                  placeholder={t.inv_phone_ph} type="tel" dir="ltr"
                  className="bg-[#0f0f0f] border border-white/10 rounded-xl px-4 py-3 text-sm font-bold text-white outline-none focus:border-[#E8BC6A] transition placeholder:text-gray-600" />
                <input value={fEmail} onChange={(e) => setFEmail(e.target.value)}
                  placeholder={t.inv_email_ph} type="email" dir="ltr"
                  className="bg-[#0f0f0f] border border-white/10 rounded-xl px-4 py-3 text-sm font-bold text-white outline-none focus:border-[#E8BC6A] transition placeholder:text-gray-600 col-span-2" />
              </div>
              <div>
                <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">{t.inv_msg_label}</p>
                <textarea value={fMsg} onChange={(e) => setFMsg(e.target.value)}
                  rows={7}
                  className="w-full bg-[#0f0f0f] border border-white/10 rounded-xl px-4 py-3 text-sm font-semibold text-gray-300 outline-none focus:border-[#E8BC6A] transition resize-none placeholder:text-gray-600" />
              </div>
              {fErr && <p className="text-red-400 text-xs font-bold">{lang === "ar" ? "الاسم والإيميل مطلوبان" : lang === "fr" ? "Le nom et l'email sont requis" : "Name and email are required"}</p>}
              <div className="flex gap-3 pt-1">
                <button onClick={() => setShowModal(false)}
                  className="flex-1 bg-white/5 text-gray-300 py-3 rounded-xl font-black hover:bg-white/10 transition">
                  {t.inv_cancel}
                </button>
                <button onClick={submitInvitation}
                  className="flex-[2] bg-[#E8BC6A] text-[#0f0f0f] py-3 rounded-xl font-black hover:bg-[#f5d898] transition">
                  {t.inv_confirm_send}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
