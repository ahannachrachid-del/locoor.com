import { useState, useEffect } from "react";
import { LangProvider } from "./context/LangContext";
import Header from "./components/Header";
import TrustBar from "./components/TrustBar";
import Footer from "./components/Footer";
import HomePage from "./pages/HomePage";
import FleetPage from "./pages/FleetPage";
import AboutPage from "./pages/AboutPage";
import ContactPage from "./pages/ContactPage";
import LoginPage from "./pages/LoginPage";
import AdminPage from "./pages/AdminPage";

type Page = "home" | "fleet" | "about" | "contact" | "login" | "admin";

const PAGES_WITH_FOOTER: Page[] = ["home", "fleet", "about", "contact"];

function AppInner() {
  const [page, setPage] = useState<Page>("home");

  const navigate = (p: string) => {
    setPage(p as Page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  useEffect(() => {
    const handler = () => {
      const bt = document.getElementById("back-top");
      if (!bt) return;
      if (window.scrollY > 400) {
        bt.style.opacity = "1";
        bt.style.pointerEvents = "auto";
      } else {
        bt.style.opacity = "0";
        bt.style.pointerEvents = "none";
      }
    };
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <div className="min-h-screen bg-[#F8F7F4] font-sans overflow-x-hidden">
      {page !== "admin" && (
        <>
          <Header page={page} setPage={navigate} />
          <TrustBar />
        </>
      )}

      <main>
        {page === "home" && <HomePage setPage={navigate} />}
        {page === "fleet" && <FleetPage />}
        {page === "about" && <AboutPage />}
        {page === "contact" && <ContactPage />}
        {page === "login" && <LoginPage setPage={navigate} />}
        {page === "admin" && <AdminPage setPage={navigate} />}
      </main>

      {PAGES_WITH_FOOTER.includes(page) && <Footer setPage={navigate} />}

      <button
        id="back-top"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className="fixed bottom-6 end-6 w-11 h-11 bg-[#0f0f0f] text-[#E8BC6A] rounded-xl shadow-lg z-50 text-xl flex items-center justify-center hover:bg-[#E8BC6A] hover:text-[#0f0f0f] transition"
        style={{ opacity: 0, pointerEvents: "none", transition: "opacity 0.3s" }}
      >
        ↑
      </button>
    </div>
  );
}

export default function App() {
  return (
    <LangProvider>
      <AppInner />
    </LangProvider>
  );
}
