import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Lang, Translations, translations } from "../i18n";

type LangContextType = {
  lang: Lang;
  t: Translations;
  setLang: (l: Lang) => void;
  isRtl: boolean;
};

const LangContext = createContext<LangContextType>({
  lang: "ar",
  t: translations.ar,
  setLang: () => {},
  isRtl: true,
});

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar");

  const setLang = (l: Lang) => {
    setLangState(l);
    document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = l;
  };

  useEffect(() => {
    document.documentElement.dir = "rtl";
    document.documentElement.lang = "ar";
  }, []);

  return (
    <LangContext.Provider value={{ lang, t: translations[lang], setLang, isRtl: lang === "ar" }}>
      {children}
    </LangContext.Provider>
  );
}

export const useLang = () => useContext(LangContext);
